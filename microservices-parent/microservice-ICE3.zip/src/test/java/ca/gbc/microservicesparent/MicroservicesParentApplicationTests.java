package ca.gbc.microservicesparent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicesParentApplicationTests {

    @Test
    void contextLoads() {
    }

}
