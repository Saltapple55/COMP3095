rootProject.name = "microservices-parent"

include("product-service","order-service","inventory-service", "api-gateway","notification-service", "shared-schema")

