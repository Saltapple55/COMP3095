package ca.gbc.inventoryservice.dto;

public class InventoryResponse {
}
