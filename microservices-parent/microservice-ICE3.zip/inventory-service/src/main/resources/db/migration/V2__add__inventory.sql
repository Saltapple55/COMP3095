INSERT INTO t_inventory (quantity, sku_code)
values (100,'SKU001'),
    (200,'SKU002'),
    (300,'SKU003'),
    (400,'SKU004'),
    (500,'SKU005')



--match model table. will be executed when boot up-will execute in naming order